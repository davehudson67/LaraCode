as.mcmc.rjags <- function(x, ...) as.mcmc.bugs(x$BUGSoutput)
